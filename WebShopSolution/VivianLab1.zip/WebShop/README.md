﻿namespace WebShop
{
    public class README
    {
    https://github.com/Viv-dn/Labb1CleanCode
    }
}
