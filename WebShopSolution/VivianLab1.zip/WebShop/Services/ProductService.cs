﻿namespace WebShop.Services;

public class ProductService
{
    
}