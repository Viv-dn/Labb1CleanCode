﻿namespace WebShop.Shared
{
    public class Class1
    {

    }
}
